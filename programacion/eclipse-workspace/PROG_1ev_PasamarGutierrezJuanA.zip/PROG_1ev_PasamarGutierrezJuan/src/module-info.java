/**
 * 
 */
/**
 * 
 */
module PROG_1ev_PasamarGutierrezJuan {
	requires teclado;
}