/**
 * 
 */
/**
 * 
 */
module PROG_2ev_PasamarGutierrezJuan {
	requires teclado;
}